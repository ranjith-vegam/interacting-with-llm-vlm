from log_manager.logger import LoggingManager


# Cache to store singleton logger instances
_logger_cache = {}


def get_logger(
    logger_name: str,
    log_level: str = "INFO",
    environment: str = "dev",
    log_path: str = "logs",
):
    """
    Returns a singleton logger instance for the given logger name.
    Each logger name will have only one instance throughout the application lifecycle.
    """
    if logger_name not in _logger_cache:
        _logger_cache[logger_name] = LoggingManager(
            logger_name, log_level, environment, log_path
        ).my_logger
    return _logger_cache[logger_name]


# def get_logger(logger_name: str):
#     """
#     Returns a singleton logger instance for the given logger name.
#     Each logger name will have only one instance throughout the application lifecycle.
#     """
#     if logger_name not in _logger_cache:
#         _logger_cache[logger_name] = LoggingManager(logger_name).my_logger
#     return _logger_cache[logger_name]
