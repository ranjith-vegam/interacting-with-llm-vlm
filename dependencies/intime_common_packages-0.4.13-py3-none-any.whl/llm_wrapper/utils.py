from llm_wrapper.models import ChatMessage
from openai.types.chat import (
    ChatCompletionMessageParam,
    ChatCompletionUserMessageParam,
    ChatCompletionAssistantMessageParam,
    ChatCompletionSystemMessageParam,
    ChatCompletionDeveloperMessageParam,
)
from typing import List


def validated_messages(
    messages: List[ChatMessage],
) -> list[ChatCompletionMessageParam]:
    processed_messages = []
    valid_roles = ["user", "assistant", "system", "developer"]

    for i, msg in enumerate(messages):
        role = msg.role
        content = msg.content

        if role not in valid_roles:
            raise ValueError(
                f"Invalid role '{role}' at message index {i}. Valid roles are: {valid_roles}"
            )

        if role == "user":
            processed_messages.append(
                ChatCompletionUserMessageParam(role="user", content=content)
            )
        elif role == "assistant":
            processed_messages.append(
                ChatCompletionAssistantMessageParam(role="assistant", content=content)
            )
        elif role == "system":
            processed_messages.append(
                ChatCompletionSystemMessageParam(role="system", content=content)
            )
        elif role == "developer":
            processed_messages.append(
                ChatCompletionDeveloperMessageParam(role="developer", content=content)
            )

    return processed_messages
