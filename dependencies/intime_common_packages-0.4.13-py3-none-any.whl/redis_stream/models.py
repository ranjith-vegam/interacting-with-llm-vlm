from typing import List, Dict, Any, Optional, Tuple
from pydantic import BaseModel, ConfigDict, model_validator
import json
import logging

logger = logging.getLogger(__name__)


class RedisStreamItemFilters(BaseModel):
    model_config = ConfigDict(extra="allow")

    hub_item_id: Optional[List[str]] = None  # for file filtering
    source: Optional[List[str]] = None  # e.g., ["sharepoint", "local"]
    file_type: Optional[List[str]] = None  # e.g., ["docx", "xlsx", "pdf"]
    # start_date, end_date in timestamp (datetime.timestamp())
    date_range: Optional[Tuple[int, int]] = None


class RedisStreamItem(BaseModel):
    model_config = ConfigDict(extra="allow")

    msg_id: Optional[str] = None
    chat_id: str
    user_id: str
    message_id: str
    socket_id: str
    user_query: str
    tenant_id: str
    account_id: str
    hub_access: List[str]  # incase of global include all hub_id's
    filters: RedisStreamItemFilters
    created_at: int  # timestamp

    def to_redis_dict(self) -> Dict[str, Any]:
        """Convert the model to a Redis-compatible dictionary by serializing complex fields to JSON."""
        logger.debug(f"Converting RedisStreamItem to Redis dict: chat_id={self.chat_id}, message_id={self.message_id}")
        try:
            data = self.model_dump()
            # Serialize lists and nested objects to JSON strings
            data["hub_access"] = json.dumps(data["hub_access"])
            data["filters"] = json.dumps(data["filters"])
            if "msg_id" in data:
                del data["msg_id"]  # don't include message id while inserting
            logger.debug(f"Successfully converted RedisStreamItem to Redis dict")
            return data
        except Exception as e:
            logger.error(f"Failed to convert RedisStreamItem to Redis dict: {e}")
            raise

    @staticmethod
    def load_from_dict(
        data: Dict[str, Any], msg_id: Optional[str] = None
    ) -> "RedisStreamItem":
        """Load a RedisStreamItem from a Redis dictionary by deserializing JSON fields."""
        logger.debug(f"Loading RedisStreamItem from dict: msg_id={msg_id}")
        try:
            # Create a copy to avoid mutating the original
            data_copy = data.copy()
            # Deserialize JSON strings back to Python objects
            if isinstance(data_copy.get("hub_access"), str):
                data_copy["hub_access"] = json.loads(data_copy["hub_access"])
            if isinstance(data_copy.get("filters"), str):
                data_copy["filters"] = json.loads(data_copy["filters"])
            data_copy["msg_id"] = msg_id
            item = RedisStreamItem(**data_copy)
            logger.debug(f"Successfully loaded RedisStreamItem: chat_id={item.chat_id}, message_id={item.message_id}")
            return item
        except Exception as e:
            logger.error(f"Failed to load RedisStreamItem from dict: msg_id={msg_id}, error={e}")
            raise

    @staticmethod
    def get_dummy(chat_id: str = "1"):
        from datetime import datetime
        dummy = {
            "chat_id": chat_id,
            "user_id": "dummy",
            "message_id": "dummy",
            "socket_id": "dummy",
            "user_query": "dummy",
            "tenant_id": "dummy",
            "account_id": "dummy",
            "hub_access": ["dummy"],
            "filters": {"hub_item_id": ["dummy"], "date_range": [0, 0]},
            "created_at": int(datetime.now().timestamp()),
        }
        return RedisStreamItem(**dummy)
