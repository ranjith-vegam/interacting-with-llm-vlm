import pytz
import os, errno
import logging
from logging.handlers import RotatingFileHandler
from datetime import datetime,timezone

# from src.config.settings import get_config

def ist_to_uts_unix(time_str):
    try:
        input_time_string = time_str
        input_datetime = datetime.strptime(input_time_string, "%d-%m-%Y %I-%M-%S %p")
        input_datetime_utc = input_datetime.astimezone(timezone.utc)
        unix_utc_timestamp_millis = int(input_datetime_utc.timestamp()) * 1000
        # print("Unix UTC Timestamp:", unix_utc_timestamp)
        return unix_utc_timestamp_millis
    except Exception as q:
        logging.error(f'Exception in ist_to_uts_unix     {str(q)}')


def unix_to_ist(unix_time):
    # Convert Unix time to seconds
    unix_time_seconds = unix_time / 1000.0
    # Convert to datetime object in UTC
    utc_time = datetime.utcfromtimestamp(unix_time_seconds)
    # Set the timezone to UTC
    utc_time = utc_time.replace(tzinfo=pytz.UTC)
    # Convert to IST (Indian Standard Time)
    ist_time = utc_time.astimezone(pytz.timezone('Asia/Kolkata'))
    # Format the datetime object as a human-readable string
    ist_time_str = ist_time.strftime('%Y-%m-%d %H:%M:%S')
    return ist_time_str



def get_current_ist_time():
    try:
        ist_timezone = pytz.timezone("Asia/Kolkata")
        utc_now = datetime.utcnow()
        ist_now = utc_now.replace(tzinfo=pytz.utc).astimezone(ist_timezone)
        formatted_ist_time = ist_now.strftime(
            "%Y-%m-%d_%H-%M-%S"
        )  # ist_now.strftime("%Y-%m-%d %H:%M:%S %Z")
        # print(type(formatted_ist_time))

        return formatted_ist_time
    except Exception as d:
        print(d)
        logging.error(f"Exception in get_current_ist_time     {str(d)}")
        return "unknown_time"


class MaxRetryReached(Exception):
    pass


# class ErrorAwareFilter(logging.Filter):
#     """
#     - Start at ERROR level (ignore INFO/WARNING).
#     - After first ERROR, switch logger level to INFO dynamically.  # DEBUG, INFO, WARNING, ERROR, CRITICAL
#     """

#     def __init__(self, logger, initial_level=logging.ERROR):
#         super().__init__()
#         self.logger = logger
#         self.error_seen = False
#         self.initial_level = initial_level
#         self.logger.setLevel(self.initial_level)

#     def filter(self, record):
#         # If error or higher happens, lower logger level to INFO-debug
#         if record.levelno >= logging.ERROR and not self.error_seen:
#             self.error_seen = True
#             self.logger.setLevel(logging.DEBUG)

#         return True  # always allow, since level now controls filtering



class ISTFormatter(logging.Formatter):
    def formatTime(self, record, datefmt=None):
        dt = datetime.utcfromtimestamp(record.created)
        utc_time = pytz.utc.localize(dt)
        ist_time = utc_time.astimezone(pytz.timezone("Asia/Kolkata"))
        # print(ist_time.strftime(datefmt) if datefmt else str(ist_time))
        return ist_time.strftime(datefmt) if datefmt else str(ist_time)


class LoggingManager:
    def __init__(
        self,
        logger_name: str,
        log_level: str = "DEBUG",
        environment: str = "dev",
        log_path: str = "logs",
    ):
        now_time_ist = get_current_ist_time()
        log_folder_name = "logs_" + now_time_ist
        if environment == "dev":
            log_folder_name = "logs"
        log_directory = f"{log_path}/{log_folder_name}/"  # "logs" if adding time in log folder, easy to getting all logs then

        self.make_sure_path_exists(log_directory)
        log_filename = os.path.join(log_directory, logger_name + ".log")

        log_format = "%(asctime)s - [%(filename)20s::%(lineno)2d] - %(levelname)12s - %(threadName)22s  - %(funcName)s - %(message)s"
        log_level = logging.getLevelName(log_level)

        # Log to file
        handler = RotatingFileHandler(
            log_filename, maxBytes=10 * 1024 * 1024, backupCount=100
        )

        date_format = "%m/%d/%Y %I:%M:%S %p"
        handler.setFormatter(ISTFormatter(log_format, datefmt=date_format))
        # handler.setFormatter(ISTFormatter(log_format))

        # Log to console
        console_handler = logging.StreamHandler()
        console_handler.setLevel(log_level)
        console_handler.setFormatter(ISTFormatter(log_format, datefmt=date_format))

        self.my_logger = logging.getLogger(logger_name)
        self.my_logger.setLevel(log_level)
        self.my_logger.addHandler(handler)
        self.my_logger.addHandler(console_handler)

        # # Add our custom filter
        # # Pass logger to the filter
        # if environment != "dev":
        #     self.my_logger.addFilter(
        #         ErrorAwareFilter(self.my_logger, initial_level=logging.ERROR)
        #     )

    @staticmethod
    def make_sure_path_exists(path):
        try:
            os.makedirs(path)
        except OSError as exception:
            if exception.errno != errno.EEXIST:
                raise
