from llm_wrapper.llm_client import LLMChatClient
from typing import Dict, List, Any, AsyncGenerator, Union
from llm_wrapper.models import (
    ChatMessage,
)
import logging


async def llm_streaming_chat(
    base_url: str,
    model_name: str,
    messages: Union[List[ChatMessage], List[dict]],
    api_key: str = "",
    timeout: int = 60,
    max_retries: int = 3,
    args: Dict[str, Any] = {},
    logger: logging.Logger = logging.getLogger(__name__),
) -> AsyncGenerator[str, None]:
    """
    Async stream chat responses from the LLM one request at a time.

    This function is an async generator that yields streaming chunks as they arrive.
    It will retry on OpenAI API errors (RateLimitError, APITimeoutError, APIConnectionError)
    up to max_retries times. Any other exceptions will be raised immediately.

    Args:
        base_url: Base URL for the API endpoint
        model_name: Name of the model to use
        messages: List of ChatMessage objects or dictionaries
        api_key: API key for authentication
        timeout: Request timeout in seconds
        max_retries: Number of retry attempts for API errors (default: 3)
        args: Additional arguments for the API call
        logger: Logger instance for logging

    Yields:
        str: Streaming chunks of the response text

    Raises:
        RateLimitError: If rate limit is exceeded after all retries
        APITimeoutError: If request times out after all retries
        APIConnectionError: If connection fails after all retries
        Exception: Any other exceptions are raised immediately

    Example:
        >>> messages = [{"role": "user", "content": "Hello!"}]
        >>> async for chunk in llm_streaming_chat(
        ...     base_url="https://api.openai.com/v1",
        ...     model_name="gpt-4",
        ...     messages=messages,
        ...     api_key="sk-..."
        ... ):
        ...     print(chunk, end="", flush=True)
    """
    client = LLMChatClient(
        logger=logger,
    )
    async for chunk in client.chat_stream_async(
        base_url=base_url,
        model_name=model_name,
        messages=messages,
        api_key=api_key,
        timeout=timeout,
        max_retries=max_retries,
        args=args,
    ):
        yield chunk
