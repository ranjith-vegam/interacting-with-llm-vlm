# from .logging_manger import LoggingManager


from log_manager.logging_manger import get_logger
from log_manager.logger import LoggingManager

__all__ = ["get_logger", "LoggingManager"]
