from typing import Dict, List, Optional, Union, Any
from llm_wrapper.llm_client import LLMChatClient
import asyncio, logging
from llm_wrapper.models import (
    LLMChatResponse,
    ChatRequest,
)


def llm_chat(
    base_url: str,
    model_name: str,
    messages_list: Union[List[List[Dict[str, str]]], List[ChatRequest]],
    api_key: str = "",
    timeout: int = 60,
    max_retries: int = 3,
    args: Dict[str, Any] = {},
    max_concurrency: Optional[int] = None,
    logger: logging.Logger = logging.getLogger(__name__),
) -> List[LLMChatResponse]:
    """
    Send one or more chat requests to the LLM with support for batch processing.

    Args:
        base_url: Base URL for the API endpoint
        model_name: Name of the model to use
        messages_list: Can be:
            - Batch requests: List[ChatRequest] or List[List[Dict[str, str]]]
        api_key: API key for authentication
        timeout: Request timeout in seconds
        max_retries: Maximum number of retry attempts per request
        args: Additional arguments for API calls
        max_concurrency: Maximum concurrent requests for this batch.
                       Overrides the client's default if provided.

    Returns:
        List[LLMChatResponse]: List of response objects for each request

    Raises:
        ValueError: If all requests in a batch fail
        Exception: If single request fails
    """
    client = LLMChatClient(
        logger=logger,
        max_concurrency=max_concurrency,
    )
    return asyncio.run(
        client.chat(
            base_url=base_url,
            api_key=api_key,
            model_name=model_name,
            messages_list=messages_list,
            timeout=timeout,
            max_retries=max_retries,
            args=args,
            max_concurrency=max_concurrency,
        )
    )


async def llm_chat_async(
    base_url: str,
    model_name: str,
    messages_list: Union[List[List[Dict[str, str]]], List[ChatRequest]],
    api_key: str = "",
    timeout: int = 60,
    max_retries: int = 3,
    args: Dict[str, Any] = {},
    max_concurrency: Optional[int] = None,
    logger: logging.Logger = logging.getLogger(__name__),
) -> List[LLMChatResponse]:
    client = LLMChatClient(
        logger=logger,
        max_concurrency=max_concurrency,
    )
    return await client.chat(
        base_url=base_url,
        api_key=api_key,
        model_name=model_name,
        messages_list=messages_list,
        timeout=timeout,
        max_retries=max_retries,
        args=args,
        max_concurrency=max_concurrency,
    )
