from typing import Dict, List, Optional, Any, Union
from pydantic import BaseModel


class LLMChatResponse(BaseModel):
    response: str | None  # None in case of failure
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    latency: float
    error_message: str | None = None  # None in case of success

    def pretty_print(self):
        print("\n====")
        print(f"Response: {self.response}")
        print(f"Prompt Tokens: {self.prompt_tokens}")
        print(f"Completion Tokens: {self.completion_tokens}")
        print(f"Total Tokens: {self.total_tokens}")
        print(f"Latency: {round(self.latency, 2)}")
        print(f"Error: {self.error_message}")
        print("====\n")


class ChatMessage(BaseModel):
    """Enhanced message model supporting both text and image content"""

    role: str
    content: Union[str, Any]


class ChatRequest(BaseModel):
    """Individual chat request within a batch"""

    messages: List[
        Union[Dict[str, Any], List[ChatMessage]]
    ]  # Support both dict and ChatMessage
    request_id: Optional[str]
    args: Dict[str, Any] = {}


class BatchResult(BaseModel):
    """Result for a single request within a batch"""

    success: bool
    data: LLMChatResponse | None
    error: Optional[str]
    request_id: Optional[str]
