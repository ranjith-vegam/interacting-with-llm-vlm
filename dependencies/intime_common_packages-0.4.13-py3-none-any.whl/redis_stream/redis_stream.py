import logging
from typing import List
import redis
from redis_stream.models import RedisStreamItem


class RedisStream:
    #  r = redis.Redis(host="localhost", port=6375, decode_responses=True, password="Pass@123")
    def __init__(
        self,
        host="localhost",
        port=6379,
        password=None,
        stream_name: str = "test",
        consumer_group: str = "test_group",
        logger: logging.Logger = logging.getLogger(__name__),
    ):
        self.logger = logger
        self.logger.info(
            f"Initializing RedisStream with host={host}, port={port}, stream_name={stream_name}, consumer_group={consumer_group}"
        )
        try:
            self.redis = redis.Redis(
                host=host, port=port, decode_responses=True, password=password
            )
            self.stream_name = stream_name
            self.consumer_group = consumer_group
            self._create_group(stream_name, consumer_group)
            self.logger.info("RedisStream initialized successfully")
        except Exception as e:
            self.logger.error(f"Failed to initialize RedisStream: {e}")
            raise

    def close(self):
        self.logger.info("Closing Redis connection")
        self.redis.close()

    def insert(self, entry: RedisStreamItem):
        self.logger.info(
            f"Inserting item into Redis stream: chat_id={entry.chat_id}, message_id={entry.message_id}"
        )
        try:
            result = self.redis.xadd(self.stream_name, entry.to_redis_dict())  # type: ignore
            self.logger.info(f"Item inserted successfully with msg_id={result}")
            return result
        except Exception as e:
            self.logger.error(f"Failed to insert item into Redis stream: {e}")
            raise

    def blocking_read(
        self,
        consumer_name: str,
        count: int,
        timeout: int = 0,  # in milliseconds
    ):
        self.logger.info(
            f"Starting blocking read: consumer={consumer_name}, count={count}, timeout={timeout}ms"
        )
        try:
            msgs = self.redis.xreadgroup(
                self.consumer_group,
                consumer_name,
                {self.stream_name: ">"},
                count=count,
                block=timeout,
            )
            response: List[RedisStreamItem] = []
            for stream, messages in msgs:  # type: ignore
                if stream != self.stream_name:
                    self.logger.warning(
                        f"Received message from unexpected stream: {stream}"
                    )
                    continue
                for msg_id, fields in messages:
                    response.append(RedisStreamItem.load_from_dict(fields, msg_id))
            self.logger.info(
                f"Blocking read completed: retrieved {len(response)} items"
            )
            return response
        except Exception as e:
            self.logger.error(f"Failed to perform blocking read: {e}")
            raise

    def _create_group(self, stream_name: str, group_name: str):
        self.logger.debug(
            f"Creating consumer group: stream={stream_name}, group={group_name}"
        )
        try:
            self.redis.xgroup_create(stream_name, group_name, mkstream=True)
            self.logger.info(
                f"Consumer group created: stream={stream_name}, group={group_name}"
            )
        except redis.ResponseError as e:
            if "BUSYGROUP" not in str(e):
                self.logger.error(f"Failed to create consumer group: {e}")
                raise e
            else:
                self.logger.info(
                    f"Consumer group already exists: stream={stream_name}, group={group_name}"
                )

    def make_as_done(self, msg_id: str):
        self.logger.info(f"Marking item as done: msg_id={msg_id}")
        try:
            result = self.redis.xack(self.stream_name, self.consumer_group, msg_id)
            self.logger.info(
                f"Item marked as done: msg_id={msg_id}, ack_count={result}"
            )
            return result
        except Exception as e:
            self.logger.error(
                f"Failed to mark item as done: msg_id={msg_id}, error={e}"
            )
            raise

    def get_failed_items(
        self,
        consumer_name: str,
        count: int = 1,
        min_idle_time: int = 10 * 60 * 1000,  # in milliseconds, default is 10 min
        start_id: str = "0-0",
    ) -> List[RedisStreamItem]:
        self.logger.info(
            f"Getting failed items with XAUTOCLAIM: consumer={consumer_name}, "
            f"count={count}, min_idle_time={min_idle_time}ms, start_id={start_id}"
        )
        try:
            # Use XAUTOCLAIM to automatically find and claim pending items
            # This is much more efficient than XPENDING_RANGE + XCLAIM
            self.logger.debug(f"Executing XAUTOCLAIM for consumer: {consumer_name}")
            result = self.redis.xautoclaim(
                name=self.stream_name,
                groupname=self.consumer_group,
                consumername=consumer_name,  # consumer who is claiming the items
                min_idle_time=min_idle_time,
                start_id=start_id,
                count=count,
            )

            # XAUTOCLAIM returns: (next_start_id, claimed_messages, deleted_message_ids)
            next_start_id, claimed_messages, deleted_ids = result  # type: ignore

            self.logger.debug(
                f"XAUTOCLAIM completed: next_start_id={next_start_id}, "
                f"claimed={len(claimed_messages)}, deleted={len(deleted_ids) if deleted_ids else 0}"
            )

            # Convert claimed messages to RedisStreamItem objects
            response: List[RedisStreamItem] = []
            for msg_id, fields in claimed_messages:  # type: ignore
                if fields:  # Skip deleted messages (fields will be None for deleted)
                    response.append(RedisStreamItem.load_from_dict(fields, msg_id))
                else:
                    self.logger.warning(f"Skipping deleted message: msg_id={msg_id}")

            self.logger.info(
                f"Failed items retrieval completed: claimed={len(response)} items, "
                f"next_start_id={next_start_id}"
            )

            return response

        except Exception as e:
            self.logger.error(f"Failed to get failed items with XAUTOCLAIM: {e}")
            raise

    def read_items(
        self,
        consumer_name: str,
        count: int = 1,
        timeout: int = 0,  # in milliseconds for blocking_read
        min_idle_time: int = 10 * 60 * 1000,  # in milliseconds for failed items check
        start_id: str = "0-0",
    ) -> List[RedisStreamItem]:
        """
        Read items from the Redis stream with failed items priority.
        First checks for failed items using XAUTOCLAIM, and if none exist,
        performs a blocking read for new items.

        Args:
            consumer_name: Name of the consumer
            count: Number of items to retrieve
            timeout: Timeout for blocking read in milliseconds (0 means infinite)
            min_idle_time: Minimum idle time in milliseconds for items to be considered failed
            start_id: Start scanning from this ID for failed items (use "0-0" for beginning)

        Returns:
            List of RedisStreamItem objects
        """
        self.logger.info(
            f"Reading items: consumer={consumer_name}, count={count}, "
            f"timeout={timeout}ms, min_idle_time={min_idle_time}ms"
        )

        try:
            # First, check for failed items using XAUTOCLAIM
            self.logger.debug("Checking for failed items first (XAUTOCLAIM)")
            failed_items = self.get_failed_items(
                consumer_name=consumer_name,
                count=count,
                min_idle_time=min_idle_time,
                start_id=start_id,
            )

            if failed_items:
                self.logger.info(
                    f"Found {len(failed_items)} failed items, returning without blocking read"
                )
                return failed_items

            # If no failed items, proceed with blocking read
            self.logger.debug("No failed items found, proceeding with blocking read")
            new_items = self.blocking_read(
                consumer_name=consumer_name, count=count, timeout=timeout
            )

            self.logger.info(
                f"Blocking read completed, retrieved {len(new_items)} new items"
            )
            return new_items

        except Exception as e:
            self.logger.error(f"Failed to read items: {e}")
            raise


if __name__ == "__main__":
    from logging import basicConfig, INFO

    basicConfig(level=INFO)
    logger = logging.getLogger(__name__)
    r = RedisStream(host="192.168.1.49", port=6375, password="Pass@123", logger=logger)
    # for i in range(10):
    #     r.insert(RedisStreamItem.get_dummy(chat_id=f"chat_{i}"))

    # Example: Get failed items using XAUTOCLAIM
    # res = r.get_failed_items(consumer_name="test_consumer", count=10, min_idle_time=10000)

    # Example: Blocking read
    # res = r.blocking_read(consumer_name="test_consumer", count=2, timeout=0)

    # Example: Read items with failed items priority
    res = r.read_items(consumer_name="test_consumer", count=10, min_idle_time=10 * 1000)
    for item in res:
        print(item.chat_id)
    # res = r.get_failed_items(
    #     consumer_name="test_consumer", count=2, min_idle_time=1 * 60 * 1000
    # )
    # for item in res:
    #     print(item.chat_id)
