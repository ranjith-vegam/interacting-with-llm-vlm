from typing import Dict, List, Optional, Union, Any, AsyncGenerator, Tuple
from openai import (
    APIConnectionError,
    AsyncOpenAI,
    RateLimitError,
    APITimeoutError,
    APIError,
)
from openai.types.chat import ChatCompletion
import asyncio, time, logging, json, re
from jsonschema import validate, ValidationError
from llm_wrapper.utils import validated_messages
from llm_wrapper.models import (
    ChatMessage,
    LLMChatResponse,
    ChatRequest,
    BatchResult,
)


class LLMChatClient:
    """
    A client for handling LLM chat requests with support for batching, retries, and caching.

    This class encapsulates all the functionality needed to make chat requests to LLM APIs,
    including client caching, retry mechanisms, batch processing, and concurrency control.
    """

    def __init__(
        self,
        logger: logging.Logger = logging.getLogger(__name__),
        max_concurrency: Optional[int] = None,
    ):
        """
        Initialize the LLM Chat Client with an empty client cache and concurrency control.

        Args:
            logger: Logger instance for logging
            max_concurrency: Maximum number of concurrent requests. If None, no limit is applied.
        """
        self.max_concurrency = max_concurrency
        self.logger = logger
        self._semaphore: Optional[asyncio.Semaphore] = (
            asyncio.Semaphore(max_concurrency) if max_concurrency is not None else None
        )

    async def _single_chat_request(
        self,
        client: AsyncOpenAI,
        model_name: str,
        messages: List[ChatMessage],
        timeout: int = 60,
        max_retries: int = 3,
        args: Optional[Dict[str, Any]] = None,
        request_id: Optional[str] = None,
    ) -> LLMChatResponse:
        """
        Handle a single chat request with retry mechanism

        Args:
            client: OpenAI client instance
            model_name: Name of the model to use
            messages: List of message dictionaries
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts
            args: Additional arguments for the API call
            request_id: Optional request identifier for logging

        Returns:
            LLMChatResponse object

        Raises:
            Exception: If all retry attempts fail
        """
        if args is None:
            args = {}

        log_context = {"request_id": request_id, "model": model_name}

        for attempt in range(max_retries + 1):
            try:
                # Validate messages
                validated_msgs = validated_messages(messages)

                # Start timing
                start_time = time.time()

                # Make API call
                self.logger.info(f"Starting request: {request_id}")
                response: ChatCompletion = await client.chat.completions.create(
                    model=model_name,
                    messages=validated_msgs,
                    timeout=timeout,
                    **args,
                )
                self.logger.info(f"Request completed: {request_id}")

                # Calculate latency
                latency = time.time() - start_time

                # Extract response content
                content = response.choices[0].message.content
                response_text = content.strip() if content else ""

                # Ensure usage is not None
                if response.usage is None:
                    raise ValueError("Response usage information is missing")

                # validate schema if exists
                schema = (
                    args.get("response_format", {})
                    .get("json_schema", {})
                    .get("schema", None)
                )
                if schema:
                    # validate schema
                    ok, validation_result = await self._validate_json_schema(
                        response_text, schema, client, model_name, args
                    )
                    if not ok:
                        self.logger.error(
                            "Failed to validate json schema: ", validation_result
                        )
                        raise Exception(
                            "Failed to validate json schema of response: ",
                            validation_result,
                        )
                    else:
                        response_text = str(validation_result)

                # Create response object
                result = LLMChatResponse(
                    response=response_text,
                    completion_tokens=response.usage.completion_tokens,
                    prompt_tokens=response.usage.prompt_tokens,
                    total_tokens=response.usage.total_tokens,
                    latency=latency,
                )

                self.logger.info(
                    f"Chat request successful",
                    extra={
                        **log_context,
                        "attempt": attempt + 1,
                        "latency": latency,
                        "total_tokens": result.total_tokens,
                    },
                )

                return result

            except (RateLimitError, APITimeoutError, APIConnectionError) as e:
                # Retryable errors
                if attempt == max_retries:
                    self.logger.error(
                        f"Chat request failed after {max_retries + 1} attempts",
                        extra={
                            **log_context,
                            "error": str(e),
                            "error_type": type(e).__name__,
                        },
                    )
                    raise

                # Exponential backoff
                wait_time = (2**attempt) + (0.1 * attempt)  # Add jitter
                self.logger.warning(
                    f"Retryable error on attempt {attempt + 1}, retrying in {wait_time}s",
                    extra={**log_context, "error": str(e), "wait_time": wait_time},
                )
                await asyncio.sleep(wait_time)

            except ValueError as e:
                # Non-retryable validation error
                self.logger.error(
                    f"Message validation failed", extra={**log_context, "error": str(e)}
                )
                raise

            except APIError as e:
                # Non-retryable API error
                self.logger.error(
                    f"API error occurred",
                    extra={
                        **log_context,
                        "error": str(e),
                        "error_type": type(e).__name__,
                    },
                )
                raise

            except Exception as e:
                # Unexpected error
                self.logger.error(
                    f"Unexpected error in chat request",
                    extra={
                        **log_context,
                        "error": str(e),
                        "error_type": type(e).__name__,
                    },
                )
                raise

        # This should never be reached due to the loop and exceptions
        raise RuntimeError("Unexpected code path in _single_chat_request")

    async def _validate_json_schema(
        self,
        json_text: str,
        schema: dict,
        client: AsyncOpenAI,
        model_name: str,
        args: dict,
    ) -> Tuple[bool, str]:
        # First attempt: raw JSON parse
        try:
            data = json.loads(json_text)
        except json.JSONDecodeError:
            self.logger.warning("Loading json failed, trying to fix with llm")
            # JSON broken → send to LLM to fix
            fixed_json_text = await self._fix_json_with_llm(
                json_text, schema, client, model_name, args
            )
            try:
                data = json.loads(fixed_json_text)
            except json.JSONDecodeError as e:
                return False, f"LLM failed to fix JSON: {e}"
            # return True, fixed_json_text

        # Validate against schema
        try:
            validate(instance=data, schema=schema)
            return True, json.dumps(data)
        except ValidationError:
            # JSON valid but not matching schema → ask LLM to correct/complete it
            self.logger.warning("Invlid json schema for LLM going for repair schema")
            repaired_json_text = await self._repair_schema_with_llm(
                data, schema, client, model_name, args
            )
            try:
                repaired = json.loads(repaired_json_text)
            except json.JSONDecodeError as e:
                return False, f"LLM repair returned invalid JSON: {e}"

            # Validate again
            try:
                validate(instance=repaired, schema=schema)
                return True, repaired_json_text
            except ValidationError as e:
                return False, f"LLM repair failed schema validation: {e.message}"

    async def _repair_schema_with_llm(
        self, data: dict, schema: dict, client: AsyncOpenAI, model_name: str, args: dict
    ) -> str:
        prompt = f"""
            The following JSON is valid but DOES NOT match the provided JSON schema.

            Fix it so that it fully matches the schema.
            Fill in missing required fields with zero-values:
            - string → ""
            - number → 0
            - array → []
            - object → {{}}
            Remove fields not present in the schema.

            SCHEMA:
            {json.dumps(schema, indent=2)}

            JSON TO FIX:
            {json.dumps(data, indent=2)}

            Return ONLY valid JSON.
        """

        response = await client.chat.completions.create(
            model=model_name,
            messages=[{"role": "user", "content": prompt}],
            **args,
        )

        content = response.choices[0].message.content
        return content if content else ""

    async def _fix_json_with_llm(
        self, text: str, schema: dict, client: AsyncOpenAI, model_name: str, args: dict
    ) -> str:
        prompt = f"""
            You are a JSON repair assistant.

            The following text is supposed to be JSON, but it is broken or incomplete.
            Fix the JSON so that it is syntactically valid.

            Then ensure it matches this JSON schema by inserting missing fields with zero-values:
            - Zero value for string → "" (empty string)
            - Zero value for array → []
            - Zero value for number → 0
            - Zero value for object → {{}}

            DO NOT add fields not in the schema.
            DO NOT return anything except final JSON.

            SCHEMA:
            {json.dumps(schema, indent=2)}

            BROKEN JSON:
            {text}

            Return ONLY valid JSON.
        """

        response = await client.chat.completions.create(
            model=model_name, messages=[{"role": "user", "content": prompt}], **args
        )

        content = response.choices[0].message.content
        # self.logger.info(f"llm response: {content}")
        return content if content else ""

    def _normalize_to_chat_requests(self, messages: Any) -> List[ChatRequest]:
        """Convert various input formats to List[ChatRequest]"""
        if isinstance(messages[0], ChatRequest):
            return messages

        if isinstance(messages[0], list):
            # List of message lists
            return [
                ChatRequest(messages=msg_list, request_id=f"req_{i}")
                for i, msg_list in enumerate(messages)
            ]

        # Single message list - treat as single request
        return [ChatRequest(messages=messages, request_id="req_0")]

    async def _process_single_request_safe(
        self,
        client: AsyncOpenAI,
        model_name: str,
        request: ChatRequest,
        timeout: int,
        max_retries: int,
        request_id: str,
        args: Dict[str, Any],
    ) -> BatchResult:
        """Safely process a single request and return BatchResult"""

        messages = []
        for msg in request.messages:
            if isinstance(msg, dict):
                try:
                    msg = ChatMessage(**msg)
                except Exception as e:
                    self.logger.error(f"Failed to convert message to ChatMessage")
                    continue
            messages.append(msg)

        async def _execute_request():
            try:
                result = await self._single_chat_request(
                    client=client,
                    model_name=model_name,
                    messages=messages,
                    timeout=timeout,
                    max_retries=max_retries,
                    args=(
                        request.args if request.args else args
                    ),  # Use request args if available, otherwise use global args
                    request_id=request_id,
                )

                return BatchResult(
                    success=True, data=result, error=None, request_id=request_id
                )

            except Exception as e:
                error_msg = f"{type(e).__name__}: {str(e)}"
                self.logger.error(f"Request {request_id} failed: {error_msg}")

                return BatchResult(
                    success=False,
                    data=LLMChatResponse(
                        response=None,
                        prompt_tokens=0,
                        completion_tokens=0,
                        total_tokens=0,
                        latency=0,
                        error_message=error_msg,
                    ),
                    error=error_msg,
                    request_id=request_id,
                )

        # Apply semaphore if concurrency limit is set
        if self._semaphore is not None:
            async with self._semaphore:
                return await _execute_request()
        else:
            return await _execute_request()

    async def chat(
        self,
        base_url: str,
        model_name: str,
        messages_list: Union[List[List[Dict[str, Any]]], List[ChatRequest]],
        api_key: str = "",
        timeout: int = 60,
        max_retries: int = 3,
        args: Dict[str, Any] = {},
        max_concurrency: Optional[int] = None,
    ) -> List[LLMChatResponse]:
        """
        Send one or more chat requests to the LLM with support for batch processing.

        Args:
            model_name: Name of the model to use
            messages_list: Can be:
                - Batch requests: List[ChatRequest] or List[List[Dict[str, str]]]
            timeout: Request timeout in seconds
            max_retries: Maximum number of retry attempts per request
            args: Additional arguments for API calls
            max_concurrency: Maximum concurrent requests for this batch.
                           Overrides the client's default if provided.

        Returns:
            List[LLMChatResponse]: List of response objects for each request

        Raises:
            ValueError: If all requests in a batch fail
            Exception: If single request fails
        """
        self.logger.info(
            f"Starting chat request(s) to {base_url} with model {model_name}"
        )
        if len(messages_list) == 0:
            self.logger.warning("No messages provided")
            return []
        async with AsyncOpenAI(base_url=base_url, api_key=api_key) as client:
            # Batch processing
            chat_requests = self._normalize_to_chat_requests(messages_list)

            # Determine effective concurrency limit
            effective_concurrency = (
                max_concurrency if max_concurrency is not None else self.max_concurrency
            )

            # Create temporary semaphore if needed for this batch
            original_semaphore = self._semaphore
            if max_concurrency is not None and max_concurrency != self.max_concurrency:
                self._semaphore = asyncio.Semaphore(max_concurrency)

            self.logger.info(
                f"Processing batch of {len(chat_requests)} requests with max_concurrency={effective_concurrency or 'unlimited'}"
            )

            # Process requests in parallel
            tasks = []
            for i, request in enumerate(chat_requests):
                request_id = request.request_id or f"req_{i}"
                task = self._process_single_request_safe(
                    client=client,
                    model_name=model_name,
                    request=request,
                    timeout=timeout,
                    max_retries=max_retries,
                    request_id=request_id,
                    args=args,
                )
                tasks.append(task)

            # Execute all requests in parallel
            # TODO: Handle expection of each request, currently all request will fail if one fails
            results = await asyncio.gather(*tasks, return_exceptions=False)

            # Restore original semaphore
            self._semaphore = original_semaphore

            # Calculate summary
            successful = sum(1 for r in results if r.success)
            failed = len(results) - successful

            summary = {
                "total_requests": len(results),
                "successful": successful,
                "failed": failed,
            }

            self.logger.info(f"Batch processing completed, summary: {summary}")

            # If all requests failed, raise an error
            if successful == 0:
                self.logger.error("All requests in batch failed")
                raise ValueError("All requests in the batch failed")

            final_result = [r.data for r in results]
            return final_result

    async def chat_stream_async(
        self,
        base_url: str,
        model_name: str,
        messages: Union[List[ChatMessage], List[dict]],
        api_key: str = "",
        timeout: int = 60,
        max_retries: int = 3,
        args: Optional[Dict[str, Any]] = None,
    ) -> AsyncGenerator[str, None]:
        if args is None:
            args = {}

        # Create async OpenAI client for streaming
        client = AsyncOpenAI(base_url=base_url, api_key=api_key, timeout=timeout)

        message_list: List[ChatMessage] = []
        for msg in messages:
            if isinstance(msg, dict):
                try:
                    msg = ChatMessage(**msg)
                    message_list.append(msg)
                except Exception as e:
                    self.logger.error(f"Failed to convert message to ChatMessage")
                    raise e
            else:
                message_list.append(msg)
        # Validate messages
        validated_msgs = validated_messages(message_list)

        log_context = {"model": model_name}

        # Retry loop
        for attempt in range(max_retries + 1):
            try:
                self.logger.info(
                    f"Starting async streaming request (attempt {attempt + 1}/{max_retries + 1})"
                )
                start_time = time.time()

                # Make streaming API call
                stream = await client.chat.completions.create(
                    model=model_name,
                    messages=validated_msgs,
                    stream=True,
                    **args,
                )

                # Yield chunks as they arrive
                async for chunk in stream:
                    if chunk.choices and len(chunk.choices) > 0:
                        delta = chunk.choices[0].delta
                        if delta.content:
                            yield delta.content

                # Log successful completion
                latency = time.time() - start_time
                self.logger.info(
                    f"Async streaming request completed successfully",
                    extra={**log_context, "attempt": attempt + 1, "latency": latency},
                )

                # Successfully completed, exit retry loop
                return

            except (RateLimitError, APITimeoutError, APIConnectionError) as e:
                # Retryable errors
                if attempt == max_retries:
                    self.logger.error(
                        f"Async streaming request failed after {max_retries + 1} attempts",
                        extra={
                            **log_context,
                            "error": str(e),
                            "error_type": type(e).__name__,
                        },
                    )
                    raise e

                # Exponential backoff
                wait_time = (2**attempt) + (0.1 * attempt)
                self.logger.warning(
                    f"Retryable error on attempt {attempt + 1}, retrying in {wait_time}s",
                    extra={**log_context, "error": str(e), "wait_time": wait_time},
                )
                await asyncio.sleep(wait_time)

            except Exception as e:
                # Non-retryable errors - raise immediately
                self.logger.error(
                    f"Non-retryable error in async streaming request",
                    extra={
                        **log_context,
                        "error": str(e),
                        "error_type": type(e).__name__,
                    },
                )
                raise

        # This should never be reached due to the loop and exceptions
        raise RuntimeError("Unexpected code path in chat_stream_async")
